navigateTo("http://demosite.appvance.com/");
setSelected(select("taxon"), "All departments")
