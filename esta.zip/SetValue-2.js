navigateTo("http://demosite.appvance.com/");
setSelected(select("taxon"), "Brands")
